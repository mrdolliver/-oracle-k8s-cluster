# Day 29 – Disaster Recovery Drill

**Objectives**
- Delete a namespace with workloads
- Restore from your saved manifests/Git

**Hints**
- `kubectl delete ns cka-drill` (create it first)
- Keep a `manifests/` folder under Git to reapply quickly
