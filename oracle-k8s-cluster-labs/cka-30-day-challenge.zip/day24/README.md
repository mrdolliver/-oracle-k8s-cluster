# Day 24 – Liveness & Readiness Probes

**Objectives**
- Add probes to a Deployment
- Break one and observe behavior

**Hints**
- `readinessProbe` vs `livenessProbe`
