# Day 8 – emptyDir Behavior

**Objectives**
- Use emptyDir to store data
- Delete pod and confirm data loss

**Hints**
- volumes.emptyDir
- Write to `/cache` then delete pod
