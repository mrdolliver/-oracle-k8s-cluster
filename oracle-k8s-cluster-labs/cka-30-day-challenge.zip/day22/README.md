# Day 22 – CrashLoopBackOff Debug

**Objectives**
- Deploy a failing pod
- Use logs and describe to find root cause

**Hints**
- `kubectl logs <pod>` and `kubectl describe pod <pod>`
