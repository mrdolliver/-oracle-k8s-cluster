# Day 12 – Network Policies

**Objectives**
- Deny-all policy in a namespace
- Allow traffic from a specific pod label

**Hints**
- Start with a default deny
- Add an allow rule selecting `from` pods by label
