# Day 28 – Multi-Resource YAML

**Objectives**
- Create Deployment, Service, and Ingress in one file
- Apply and test end-to-end

**Hints**
- Separate resources with `---`
