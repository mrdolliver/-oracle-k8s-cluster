# Day 6 – Namespaces & Contexts

**Objectives**
- Create namespaces `dev`, `stage`
- Switch contexts and default namespace

**Hints**
- `kubectl create ns dev`
- `kubectl config set-context --current --namespace=dev`
