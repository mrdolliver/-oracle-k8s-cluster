# Day 23 – Metrics Server

**Objectives**
- Install metrics-server
- Use `kubectl top` for nodes and pods

**Hints**
- Check RBAC and flags for insecure TLS if needed in labs
