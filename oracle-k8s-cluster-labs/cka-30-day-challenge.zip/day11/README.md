# Day 11 – Ingress for Two Apps

**Objectives**
- Install ingress-nginx
- Serve /app1 and /app2 on same IP

**Hints**
- Deploy two Deployments/Services
- Create a path-based Ingress
