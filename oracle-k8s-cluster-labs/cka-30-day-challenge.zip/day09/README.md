# Day 9 – PV/PVC with OCI Block Volume

**Objectives**
- Create a PV and PVC
- Mount into a Pod and verify persistence

**Hints**
- Ensure your CSI/Provisioner is set up (OCI Block Storage)
- `ReadWriteOnce` typical
